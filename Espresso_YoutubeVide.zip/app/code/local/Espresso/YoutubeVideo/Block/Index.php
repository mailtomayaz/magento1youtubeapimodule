<?php   
class Espresso_YoutubeVideo_Block_Index extends Mage_Core_Block_Template{   

public function getVideoList($nPageToken='')
     {
        $apiKey = Mage::getModel('core/variable')->loadByCode('youtubeapikey')->getValue('plain');
        $channelId =Mage::getModel('core/variable')->loadByCode('channelId')->getValue('plain');
        $maxResult = Mage::getModel('core/variable')->loadByCode('maxresultsyoutubevideo')->getValue('plain');
        $videoList = json_decode(file_get_contents('https://www.googleapis.com/youtube/v3/search?order=date&part=snippet&channelId=' . $channelId . '&maxResults=' . $maxResult . '&key=' . $apiKey . '&pageToken='.$nPageToken.''));
        return $videoList;

     }
         public function getplaylist(){
     $apiKey = Mage::getModel('core/variable')->loadByCode('youtubeapikey')->getValue('plain');
        $channelId =Mage::getModel('core/variable')->loadByCode('channelId')->getValue('plain');
        $maxResult = Mage::getModel('core/variable')->loadByCode('maxresultsyoutubevideo')->getValue('plain');
        $nPageToken = $_POST['pageToken'];
  //   echo 'https://www.googleapis.com/youtube/v3/search?order=date&part=snippet&channelId=' . $channelId . '&maxResults=' . $maxResult . '&key=' . $apiKey . '&pageToken='.$nPageToken;
      // https://www.googleapis.com/youtube/v3/playlists?part=snippet&channelId=UCzorwazQ9sB73AmUqv88brw&maxResults=15&key=AIzaSyCnCFQtKW91Y_8luF4gQ_zdPfzCQvCyAMo
        $videoList = json_decode(file_get_contents('https://www.googleapis.com/youtube/v3/playlists?part=snippet&channelId=' . $channelId . '&maxResults=' . $maxResult . '&key=' . $apiKey ));
       return $videoList;
      // echo "<pre>";
    


    }
    public function getplaylistvideos(){
    $apiKey = Mage::getModel('core/variable')->loadByCode('youtubeapikey')->getValue('plain');
    $channelId =Mage::getModel('core/variable')->loadByCode('channelId')->getValue('plain');
    $maxResult = Mage::getModel('core/variable')->loadByCode('maxresultsyoutubevideo')->getValue('plain');
    $nPageToken = $_POST['pageToken'];
  //   echo 'https://www.googleapis.com/youtube/v3/search?order=date&part=snippet&channelId=' . $channelId . '&maxResults=' . $maxResult . '&key=' . $apiKey . '&pageToken='.$nPageToken;
      // https://www.googleapis.com/youtube/v3/playlists?part=snippet&channelId=UCzorwazQ9sB73AmUqv88brw&maxResults=15&key=AIzaSyCnCFQtKW91Y_8luF4gQ_zdPfzCQvCyAMo
    $videoList = json_decode(file_get_contents('https://www.googleapis.com/youtube/v3/playlists?part=snippet&channelId=' . $channelId . '&maxResults=' . $maxResult . '&key=' . $apiKey ));
    return $videoList;
    // echo "<pre>";
    }
     public function getplaylistbyid($id){
    $apiKey = Mage::getModel('core/variable')->loadByCode('youtubeapikey')->getValue('plain');
    $channelId =Mage::getModel('core/variable')->loadByCode('channelId')->getValue('plain');
    $maxResult = Mage::getModel('core/variable')->loadByCode('maxresultsyoutubevideo')->getValue('plain');
    $nPageToken = $_POST['pageToken'];
  //   echo 'https://www.googleapis.com/youtube/v3/search?order=date&part=snippet&channelId=' . $channelId . '&maxResults=' . $maxResult . '&key=' . $apiKey . '&pageToken='.$nPageToken;
      // https://www.googleapis.com/youtube/v3/playlists?part=snippet&channelId=UCzorwazQ9sB73AmUqv88brw&maxResults=15&key=AIzaSyCnCFQtKW91Y_8luF4gQ_zdPfzCQvCyAMo&id=PLQ3lZP_kczLK676ucdvdWuzHdpETXa_zc;
    $videoList = json_decode(file_get_contents('https://www.googleapis.com/youtube/v3/playlists?part=snippet&channelId=' . $channelId . '&maxResults=' . $maxResult . '&key=' . $apiKey.'&playlistId='.$id ));
    return $videoList;
    // echo "<pre>";
    }

}