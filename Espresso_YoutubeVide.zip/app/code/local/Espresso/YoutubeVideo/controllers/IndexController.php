<?php
class Espresso_YoutubeVideo_IndexController extends Mage_Core_Controller_Front_Action{
    
         
    public function IndexAction() {
       
	  $this->loadLayout();   
	  $this->getLayout()->getBlock("head")->setTitle($this->__("Videos"));
	        $breadcrumbs = $this->getLayout()->getBlock("breadcrumbs");
      $breadcrumbs->addCrumb("home", array(
                "label" => $this->__("Home"),
                "title" => $this->__("Home"),
                "link"  => Mage::getBaseUrl()
		   ));

      $breadcrumbs->addCrumb("videos", array(
                "label" => $this->__("videos"),
                "title" => $this->__("videos")
		   ));

      $this->renderLayout(); 
	  
    }

    public function getdataAction(){
        $apiKey = Mage::getModel('core/variable')->loadByCode('youtubeapikey')->getValue('plain');
        $channelId =Mage::getModel('core/variable')->loadByCode('channelId')->getValue('plain');
        $maxResult = Mage::getModel('core/variable')->loadByCode('maxresultsyoutubevideo')->getValue('plain');
        $nPageToken = $_POST['pageToken'];
  //   echo 'https://www.googleapis.com/youtube/v3/search?order=date&part=snippet&channelId=' . $channelId . '&maxResults=' . $maxResult . '&key=' . $apiKey . '&pageToken='.$nPageToken;
        $videoList = json_decode(file_get_contents('https://www.googleapis.com/youtube/v3/search?order=date&part=snippet&channelId=' . $channelId . '&maxResults=' . $maxResult . '&key=' . $apiKey . '&pageToken='.$nPageToken.''));
       
        foreach ($videoList->items as $item) {
            //Embed video
           // echo $item->id->videoId.'';
            if (isset($item->id->videoId)) {
                echo '<div class="youtube-video col-lg-4 col-md-4 col-xs-12">
                <iframe width="100%" height="300" src="https://www.youtube.com/embed/' . $item->id->videoId . '" frameborder="0" allowfullscreen></iframe>
                <h5>' . $item->snippet->title . '</h5>
            </div>';

            }
        }

    }
       public function getplaylistAction(){
     $apiKey = Mage::getModel('core/variable')->loadByCode('youtubeapikey')->getValue('plain');
        $channelId =Mage::getModel('core/variable')->loadByCode('channelId')->getValue('plain');
        $maxResult = Mage::getModel('core/variable')->loadByCode('maxresultsyoutubevideo')->getValue('plain');
        $nPageToken = $_POST['pageToken'];
  //   echo 'https://www.googleapis.com/youtube/v3/search?order=date&part=snippet&channelId=' . $channelId . '&maxResults=' . $maxResult . '&key=' . $apiKey . '&pageToken='.$nPageToken;
      // https://www.googleapis.com/youtube/v3/playlists?part=snippet&channelId=UCzorwazQ9sB73AmUqv88brw&maxResults=15&key=AIzaSyCnCFQtKW91Y_8luF4gQ_zdPfzCQvCyAMo
        $videoList = json_decode(file_get_contents('https://www.googleapis.com/youtube/v3/playlists?part=snippet&channelId=' . $channelId . '&maxResults=' . $maxResult . '&key=' . $apiKey ));
       return $videoList;
      // echo "<pre>";
     // print_r($videoList);
//        echo "<seclect>";
//        foreach ($videoList->items as $item) {
//            //Embed video
//       //   echo $playListId = $item->id;
//          //print_r($item->snippet->thumbnails);
//         // echo $item->snippet->thumbnails->medium->url;
//            if (isset($item->id)) {
//                // <iframe width="100%" height="300" src="https://www.youtube.com/embed/' . $item->id . '" frameborder="0" allowfullscreen></iframe>
//               // echo '<div class="youtube-video col-lg-4 col-md-4 col-xs-12"><h5>' . $item->snippet->title . '</h5></div>';
//               echo "<option value=".$item->id.">".$item->snippet->title."</option>";
//
//            }
//        }
//        echo "</select>";

    }
    
}